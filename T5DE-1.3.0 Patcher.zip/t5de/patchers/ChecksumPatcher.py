import inspect
import os
import shutil

from .Patcher import Patcher
from ..patches import checksum as checksum_patches


class ChecksumPatcher(Patcher):
    def __init__(self, cwd):
        """
        :param str cwd:
        """
        super(ChecksumPatcher, self).__init__(
            cwd,
            [cls() for name, cls in inspect.getmembers(checksum_patches, inspect.isclass)]
        )

    def setup(self):
        checksum_file = os.path.join(self.cwd, 'IMVUClient', 'checksum.txt')
        if os.path.isfile(checksum_file):
            print('COPYING: CHECKSUM.TXT')
            shutil.copy(checksum_file, os.path.join(self.cwd, 'checksum.txt'))

    def cleanup(self):
        local_checksum = os.path.join(self.cwd, 'checksum.txt')
        dest_checksum = os.path.join(self.cwd, 'IMVUClient', 'checksum.txt')
        if os.path.isfile(local_checksum):
            print('REPLACING: CHECKSUM.TXT')
            if os.path.isfile(dest_checksum):
                shutil.copy(local_checksum, dest_checksum)
            print('REMOVING: CHECKSUM.TXT')
            os.remove(local_checksum)

        df_exe = os.path.join(self.cwd, 'IMVUClient', 'devicefingerprint.exe')
        if os.path.isfile(df_exe):
            print('REMOVING: DEVICEFINGERPRINT.EXE')
            os.remove(df_exe)
