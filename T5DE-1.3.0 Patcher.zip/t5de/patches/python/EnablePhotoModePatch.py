from ...patch import PythonPatch


class EnablePhotoModePatch(PythonPatch):
    def __init__(self):
        super(EnablePhotoModePatch, self).__init__()

        self.register('ENABLE_PHOTO_MODE', 'imvu/mode/ShopMode.py', r'def addChatTool\(self\):')
        self.register('ENABLE_IN_SHOP', 'imvu/client/sessionwindow.py', r'self\.__isInShop\(\) and not self\.__userAccount\.isAdmin\(\)')

    def patch(self, context):
        if context.pattern == 'ENABLE_PHOTO_MODE':
            context.write('@property\n', indent=1)
            context.write('def commonModeUiDisabledFeatures(self):\n', indent=1)
            context.write("return ['invite-friend']\n\n", indent=2)

            context.write(context.line)
            context.write('self.addChatToolNoCheck()\n', indent=2)
            context.write('return\n', indent=2)
            context.seek(1)
        elif context.pattern == 'ENABLE_IN_SHOP':
            context.seek(1)
