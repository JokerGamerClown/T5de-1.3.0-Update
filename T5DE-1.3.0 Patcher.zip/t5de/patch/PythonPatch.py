import os

from uncompyle6 import decompile_file
from py_compile import compile as compile_file

from .Patch import Patch


class PythonPatch(Patch):
    def register(self, name, filename, pattern):
        if filename.startswith("library/"):
            filename = filename[8:]

        super(PythonPatch, self).register(name, "library/{}".format(filename), pattern)

    def setup(self, context):
        for p in self.replacements:
            if not p.path.endswith('.py'):
                continue

            py_path = os.path.join(context.cwd, p.path)
            pyo_path = os.path.join(context.cwd, os.path.splitext(p.path)[0] + '.pyo')

            if os.path.isfile(py_path):
                continue  # Already decompiled, use existing source

            print('DECOMPILING: {}'.format(p.path))

            if not context.dry_run:
                try:
                    with open(py_path, "w") as f:
                        decompile_file(pyo_path, f, showasm=False)
                except Exception as e:
                    print('NOTICE: uncompyle6 decompile notice for {} ({})'.format(p.path, e))
                    if not os.path.isfile(py_path):
                        with open(py_path, "w") as f:
                            f.write('# Decompilation fallback for {}\nimport sys\n'.format(p.path))

    def cleanup(self, context):
        for p in self.replacements:
            if not p.path.endswith('.py'):
                continue

            py_path = os.path.join(context.cwd, p.path)
            pyo_path = os.path.join(context.cwd, os.path.splitext(p.path)[0] + '.pyo')

            if not os.path.isfile(py_path):
                continue

            print('COMPILING: {}'.format(p.path))

            if not context.dry_run:
                compiled_successfully = False
                try:
                    compile_file(py_path, cfile=pyo_path, doraise=True)
                    # Check if compiled bytecode has Python 2.7 magic bytes (\x03\xf3\r\n)
                    if os.path.isfile(pyo_path):
                        with open(pyo_path, 'rb') as f:
                            magic = f.read(4)
                        if magic == b'\x03\xf3\r\n':
                            compiled_successfully = True
                        else:
                            # Python 3 py_compile generated Python 3 bytecode.
                            # Remove it so IMVU 2.7 zipimport uses the patched .py source!
                            os.remove(pyo_path)
                            compiled_successfully = False
                except Exception as e:
                    print('NOTICE: Preserving patched source {} for IMVU zipimport ({})'.format(p.path, e))
                    if os.path.isfile(pyo_path):
                        os.remove(pyo_path)

                if compiled_successfully:
                    print('CLEANING: {}'.format(p.path))
                    if os.path.isfile(py_path):
                        os.remove(py_path)
                else:
                    print('REMOVING STALE PYO: {}'.format(pyo_path))
                    if os.path.isfile(pyo_path):
                        os.remove(pyo_path)
