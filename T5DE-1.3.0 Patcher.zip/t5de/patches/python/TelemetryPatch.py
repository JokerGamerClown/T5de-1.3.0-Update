from ...patch import PythonPatch
import base64


class TelemetryPatch(PythonPatch):
    def __init__(self):
        super(TelemetryPatch, self).__init__()

        self.register('TELEMETRY_1', 'imvu/imq/imqconnection.py', r'def __recordPreAuthClose')
        self.register('TELEMETRY_2', 'imvu/mode/ProductEditMode.py', r'self\.__recordSaveException')
        self.register('TELEMETRY_3', 'imvu/mode/SettingsMode.py', r'def handle_sendLogs')
        self.register('TELEMETRY_4', 'imvu/account.py', r'def recordModeOpen')
        self.register('TELEMETRY_5', 'imvu/account.py', r'\'room_id\': room_id')
        self.register('TELEMETRY_6', 'main/bugzilla_submit.py', r'def submitImvuBug')
        self.register('TELEMETRY_7', 'main/clientapp.py', r'sendLogsOnLogin')
        self.register('TELEMETRY_8', 'main/SendIMVULogs.py', r'def send\(')
        self.register('TELEMETRY_9', 'main/SendIMVULogs.py', r'def send_internal\(')
        self.register('TELEMETRY_10', 'imvu/devicefingerprint.py', r'import')
        self.register('TELEMETRY_11', 'imvu/log.py', r'def getRecords')
        self.register('TELEMETRY_12', 'imvu/mode/HomeMode.py', r'def loadFPEdgeUrl')
        self.register('TELEMETRY_13', 'imvu/account.py', r'def getUpdateInfo')
        self.register('TELEMETRY_14', 'imvu/account.py', r'self\.__factReporter\.recordFact\(')
        self.register('TELEMETRY_15', 'imvu/account.py', r'self\.__factReporter\.recordFactOnlyOnce\(')

    def patch(self, context):
        if context.pattern == 'TELEMETRY_1':
            context.write(context.line)
            context.write('pass\n', indent=2)
            context.seek(12)
        elif context.pattern == 'TELEMETRY_2':
            context.write('pass\n', indent=5)
            context.seek(0)
        elif context.pattern == 'TELEMETRY_3':
            context.write(context.line)
            context.write('pass\n', indent=2)
            context.seek(3)
        elif context.pattern == 'TELEMETRY_4':
            context.write(context.line)
            context.write('pass\n', indent=2)
            context.seek(3)
        elif context.pattern == 'TELEMETRY_5':
            context.write('\'room_id\': \'\'}', indent=3)
            context.seek(0)
        elif context.pattern == 'TELEMETRY_6':
            context.write(context.line)
            context.write('pass\n', indent=1)
            context.seek(len(context.source), absolute=True)
        elif context.pattern == 'TELEMETRY_7':
            context.seek(2)
        elif context.pattern == 'TELEMETRY_8':
            context.write(context.line)
            context.write('pass\n', indent=1)
            context.seek(6)
        elif context.pattern == 'TELEMETRY_9':
            context.write(context.line)
            context.write('return False\n', indent=1)
            context.seek(len(context.source), absolute=True)
        elif context.pattern == 'TELEMETRY_10':
            fp = base64.b64decode("ZGV2aWNlZmluZ2VycHJpbnQucHlk").decode('utf-8')
            context.write('def __load():\n')
            context.write('import imp, os, sys\n', indent=1)
            context.write('try:\n', indent=1)
            context.write('dirname = os.path.dirname(__loader__.archive)\n', indent=2)
            context.write('except NameError:\n', indent=1)
            context.write('dirname = sys.prefix\n', indent=2)
            context.write("path = os.path.join(dirname, \'{}\')\n".format(fp), indent=1)
            context.write('mod = imp.load_dynamic(__name__, path)\n', indent=1)
            context.write('__load()\n')
            context.write('del __load\n')
            context.seek(len(context.source), absolute=True)
        elif context.pattern == 'TELEMETRY_11':
            context.write(context.line)
            context.write('self.clearRecords()\n', indent=2)
            context.write('return []\n', indent=2)
            context.seek(4)
        elif context.pattern == 'TELEMETRY_12':
            context.write(context.line)
            context.write('pass\n', indent=2)
            context.seek(6)
        elif context.pattern == 'TELEMETRY_13':
            context.write('def shouldRecordFact(self, fact_type):\n', indent=1)
            context.write('__facts = ["NUI:CreatorMode", "NUI:ProductEditMode", "Create Mode Edit Pid", "Create Mode Derive Pid", "Create Mode Open Chkn", "Create Mode Open Cfl"]\n', indent=2)
            context.write('if (fact_type in __facts) and not self.chkCreator():\n', indent=2)
            context.write('return False\n', indent=3)
            context.write('return True\n\n', indent=2)
            context.write(context.line)
            context.seek(0)
        elif context.pattern in ('TELEMETRY_14', 'TELEMETRY_15'):
            context.write('if self.shouldRecordFact(fact_type):\n', indent=2)
            context.write(context.line.strip(), indent=3)
            context.seek(0)
