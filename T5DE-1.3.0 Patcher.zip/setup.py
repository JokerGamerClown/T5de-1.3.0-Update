#!/usr/bin/env python
import os
try:
    from setuptools import setup, find_packages
except ImportError:
    from distutils.core import setup, find_packages

# The directory containing this file
HERE = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(HERE, 'README.md')) as f:
    README = f.read()

version_ns = {}
with open(os.path.join(HERE, 't5de', 'version.py')) as f:
    exec(f.read(), version_ns)

version = version_ns['__version__']

print('Running T5DE patcher setup v%s' % version)

setup(
    name='T5DE',
    version=version,
    description='A modified IMVU client that unlocks useful features.',
    long_description=README,
    long_description_content_type='text/markdown',
    url='https://github.com/dhkatz/t5de',
    packages=find_packages(),
    install_requires=[
        'autogui',
        'requests',
        'uncompyle6',
        'typing',
        'beautifulsoup4',
        'python-dotenv'
    ],
    entry_points={
        'console_scripts': [
            't5de = t5de.__main__:main'
        ]
    }
)
