import inspect
import os
import shutil
import zipfile

from ..patches import interface
from .Patcher import Patcher


class InterfacePatcher(Patcher):
    """
    Extracts the imvuContent.jar file from the IMVUClient directory and replaces it with the imvuContent.jar file from
    the patches before then re-archiving the imvuContent.jar file and replacing the original imvuContent.jar file.
    """
    def __init__(self, cwd):
        """
        :param str cwd:
        """
        super(InterfacePatcher, self).__init__(
            cwd,
            [cls() for name, cls in inspect.getmembers(interface, inspect.isclass)]
        )

    def setup(self):
        jar_path = os.path.join(self.cwd, 'IMVUClient', 'ui', 'chrome', 'imvuContent.jar')
        if os.path.isfile(jar_path):
            print('EXTRACTING: IMVUCONTENT.jar')
            with zipfile.ZipFile(jar_path, 'r') as zip_file:
                zip_file.extractall(os.path.join(self.cwd, 'imvuContent'))
        else:
            print('NOTICE: imvuContent.jar not found at %s' % jar_path)

    def cleanup(self):
        content_dir = os.path.join(self.cwd, 'imvuContent')
        if not os.path.isdir(content_dir):
            return

        print('ARCHIVING: IMVUCONTENT.JAR')

        with zipfile.ZipFile(os.path.join(self.cwd, 'imvuContent.jar'), 'w', compression=zipfile.ZIP_STORED) as z:
            for root, dirs, files in os.walk(content_dir):
                for filename in files:
                    filepath = os.path.join(root, filename)
                    z.write(filepath, os.path.relpath(filepath, content_dir))

        print('ARCHIVED: IMVUCONTENT.JAR')

        dest_dir = os.path.join(self.cwd, 'IMVUClient', 'ui', 'chrome')
        dest_jar = os.path.join(dest_dir, 'imvuContent.jar')
        if os.path.isdir(dest_dir):
            print('REPLACING: IMVUCONTENT.jar')
            if os.path.isfile(dest_jar):
                os.remove(dest_jar)
            shutil.move(os.path.join(self.cwd, 'imvuContent.jar'), dest_dir)
        else:
            if os.path.isfile(os.path.join(self.cwd, 'imvuContent.jar')):
                os.remove(os.path.join(self.cwd, 'imvuContent.jar'))

        if os.path.isdir(content_dir):
            shutil.rmtree(content_dir)
