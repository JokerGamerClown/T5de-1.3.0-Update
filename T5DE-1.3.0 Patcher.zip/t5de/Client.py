import os
import shutil
import time
import zipfile

try:
    import autogui
except Exception:
    autogui = None

import requests
from bs4 import BeautifulSoup

from typing import List


# noinspection PyBroadException
class Client:
    """
    A class to manage the IMVU client

    Attributes:
        cwd (str): The current working directory
        version (str): The version of IMVU to manipulate
    """

    BASE_URL = 'https://static-akm.imvu.com/imvufiles/installers/InstallIMVU_{}.exe'
    VERSION_URL = 'https://www.imvu.com/download.php'

    @classmethod
    def get_client_path(cls):
        local_appdata = os.getenv('LOCALAPPDATA') or os.path.expanduser('~/AppData/Local')
        roaming_appdata = os.getenv('APPDATA') or os.path.expanduser('~/AppData/Roaming')
        
        path1 = os.path.join(local_appdata, 'IMVUClient')
        path2 = os.path.join(roaming_appdata, 'IMVUClient')
        
        if os.path.isdir(path1):
            return path1
        if os.path.isdir(path2):
            return path2
        return path1

    def __init__(self, version=None, cwd=None):
        """
        :param str|None version: The version of IMVU to manipulate, if None, the latest version is used
        :param str|None cwd: The current working directory
        """
        self.cwd = cwd or os.getcwd()
        self.version = version or self._latest_version()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()

    def download(self):
        """
        Download the IMVU client executable if it does not exist

        :return: True if the executable was downloaded, False otherwise
        :rtype: bool
        """
        print('DOWNLOADING: IMVU {}'.format(self.version))
        exe_path = os.path.join(self.cwd, 'InstallIMVU_%s.exe' % self.version)
        if os.path.isfile(exe_path):
            return False

        r = requests.get(Client.BASE_URL.format(self.version))

        with open(exe_path, 'wb') as f:
            f.write(r.content)

        return True

    def install(self, download=False):
        """
        Install the IMVU client using the downloaded executable
        :param bool download: Download the executable if it does not exist
        """
        exe_path = os.path.join(self.cwd, 'InstallIMVU_%s.exe' % self.version)
        if not os.path.isfile(exe_path):
            if download:
                self.download()
            else:
                raise IOError('Could not find InstallIMVU_{}.exe'.format(self.version))

        print('INSTALLING: IMVU {}'.format(self.version))
        if autogui is None:
            raise RuntimeError("autogui is not available on this platform. Automatic client installation requires Windows.")
        autogui.open(exe_path, setActive=False)
        attempts = 0
        while attempts < 5:
            attempts += 1
            try:
                autogui.setWindow('IMVU Setup')
                autogui.click('Install', 0, 4)
                break
            except Exception:
                if attempts > 5:
                    raise RuntimeError('Could not automate IMVU install! Failed to find Setup window.')
                print('SLEEPING: 5 SECONDS...')
                time.sleep(5)
        print('SLEEPING: 15 SECONDS...')
        time.sleep(15)

        attempts = 0
        while attempts < 5:
            attempts += 1
            try:
                if autogui.exists('Update Available'):
                    print('SKIPPING: UPDATE AVAILABLE PROMPT')
                    autogui.setWindow('Update Available', timeout=4)
                    autogui.click('Close', timeout=4)
                    time.sleep(5)
                autogui.setWindow('IMVU Login')
                autogui.click('Close', timeout=4)
                break
            except Exception:
                if attempts > 5:
                    raise RuntimeError('Could not automate IMVU install! Failed to find Login window.')
                print('SLEEPING: 5 SECONDS...')
                time.sleep(5)

        print('INSTALLED: IMVU {}'.format(self.version))

    def copy(self):
        src_path = self.get_client_path()
        print('COPYING: {}'.format(src_path))

        if not os.path.isdir(src_path):
            raise IOError('IMVUClient directory not found at {}'.format(src_path))

        dest_client = os.path.join(self.cwd, 'IMVUClient')
        if os.path.isdir(dest_client):
            shutil.rmtree(dest_client)

        shutil.copytree(
            src_path, dest_client,
            ignore=shutil.ignore_patterns('*.lock')
        )

        dev_fp = os.path.join(self.cwd, 'scripts/devicefingerprint.pyd')
        if os.path.isfile(dev_fp):
            print('COPYING: devicefingerprint.pyd')
            shutil.copy(dev_fp, dest_client)

        exe_path = os.path.join(self.cwd, 'InstallIMVU_%s.exe' % self.version)
        if not os.path.isfile(exe_path):
            try:
                self.download()
            except Exception as e:
                print('NOTICE: Could not download installer: {}'.format(e))

        if os.path.isfile(exe_path):
            print('RESTORING PRISTINE library.zip FROM {}'.format(os.path.basename(exe_path)))
            try:
                with zipfile.ZipFile(exe_path, 'r') as z:
                    if 'library.zip' in z.namelist():
                        z.extract('library.zip', dest_client)
            except Exception as e:
                print('NOTICE: Could not extract library.zip from installer: {}'.format(e))

    def patch(self, patchers, dry_run=False):
        """
        Patch the IMVU client
        :param List patchers: A list of patchers to run
        :param bool dry_run: Do not apply patches, only simulate
        """
        if not os.path.isdir(os.path.join(self.cwd, 'IMVUClient')):
            raise IOError('Could not find IMVUClient directory')

        for Patcher in patchers:
            patcher = Patcher(self.cwd)
            patcher.setup()
            print('PROCESSING PATCHER: {}'.format(Patcher.__name__))
            patcher.patch(dry_run)
            patcher.cleanup()

    def deploy(self):
        target = self.get_client_path()
        source = os.path.join(self.cwd, 'IMVUClient')
        if os.path.isdir(source) and os.path.isdir(os.path.dirname(target)):
            print('DEPLOYING PATCHED CLIENT TO: {}'.format(target))
            for item in os.listdir(source):
                s_item = os.path.join(source, item)
                t_item = os.path.join(target, item)
                if os.path.isfile(s_item):
                    shutil.copy2(s_item, t_item)
                elif os.path.isdir(s_item) and item != '__pycache__':
                    os.makedirs(t_item, exist_ok=True)
                    for r, d, files in os.walk(s_item):
                        rel = os.path.relpath(r, s_item)
                        dest_dir = os.path.join(t_item, rel)
                        os.makedirs(dest_dir, exist_ok=True)
                        for f in files:
                            shutil.copy2(os.path.join(r, f), os.path.join(dest_dir, f))
            print('DEPLOYED SUCCESSFULLY!')

    def cleanup(self):
        executable = os.path.join(self.cwd, 'InstallIMVU_%s.exe' % self.version)
        if os.path.isfile(executable):
            os.remove(executable)

    def diff(self, generators, version=None):
        """
        :param List[constructor] generators: A list of diff generators
        :param str version: The version to diff against, if None, the latest version is used
        """
        if version is None:
            version = self._latest_version()

        if self.version == version:
            print('SKIPPED: IMVU {} and IMVU {} are the same'.format(self.version, version))
            return

        if os.path.isdir(os.path.join(self.cwd, 'IMVUClient-{}'.format(self.version))):
            shutil.rmtree(os.path.join(self.cwd, 'IMVUClient-{}'.format(self.version)))

        print('DIFFING: IMVU {} and IMVU {}'.format(self.version, version))

        # Download the previous version first
        self.download()
        self.install()
        self.copy()

        # Rename the previous version to IMVUClient-{version}
        if os.path.isdir(os.path.join(self.cwd, 'IMVUClient-{}'.format(self.version))):
            shutil.rmtree(os.path.join(self.cwd, 'IMVUClient-{}'.format(self.version)))

        shutil.move(os.path.join(self.cwd, 'IMVUClient'), os.path.join(self.cwd, 'IMVUClient-{}'.format(self.version)))

        # Download the current version
        current_version = self.version
        self.version = version

        self.download()
        self.install()
        self.copy()

        # Rename the current version to IMVUClient-{current}
        if os.path.isdir(os.path.join(self.cwd, 'IMVUClient-{}'.format(version))):
            shutil.rmtree(os.path.join(self.cwd, 'IMVUClient-{}'.format(version)))

        shutil.move(os.path.join(self.cwd, 'IMVUClient'), os.path.join(self.cwd, 'IMVUClient-{}'.format(version)))

        self.version = current_version

        previous_cwd = os.path.join(self.cwd, 'IMVUClient-{}'.format(self.version))
        current_cwd = os.path.join(self.cwd, 'IMVUClient-{}'.format(version))

        for Generator in generators:
            print('PROCESSING DIFF GENERATOR: {}'.format(Generator.__name__))
            with Generator(self.cwd, self.version, version, previous_cwd, current_cwd) as generator:
                generator.diff()

        executable = os.path.join(self.cwd, 'InstallIMVU_%s.exe' % version)
        if os.path.isfile(executable):
            try:
                os.remove(executable)
            except Exception as e:
                print('ERROR: {}'.format(e))
                pass

    def _latest_version(self):
        """
        Get the latest version of IMVU
        :return: The latest version of IMVU
        :rtype: str
        """
        response = requests.get(Client.VERSION_URL)
        soup = BeautifulSoup(response.content, 'html.parser')
        h2 = soup.find(lambda tag: tag.name == 'h2' and 'IMVU Classic:' in tag.text)
        if not h2:
            h2 = soup.find('h2', text='IMVU Classic:')
        b = h2.find_next('b')
        return b.text.strip().rstrip(':')
