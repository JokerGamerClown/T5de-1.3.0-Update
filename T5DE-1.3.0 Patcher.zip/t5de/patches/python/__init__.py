from .AccountPatch import AccountPatch
from .TelemetryPatch import TelemetryPatch
from .WindowsPatch import WindowsPatch
from .EnablePhotoModePatch import EnablePhotoModePatch
