from ...patch import PythonPatch


class AccountPatch(PythonPatch):
    def __init__(self):
        super(AccountPatch, self).__init__()

        self.register("ENABLE_CREATOR", "imvu/account.py", r'def isCreator\(self\):')
        self.register("DISABLE_CLIENT_ADS", "imvu/account.py", r'def showClientAds\(self\):')
        self.register("DISABLE_ROOM_ADS", "imvu/account.py", r'def showRoomLoadingAds\(self\):')

    def patch(self, context):
        if context.pattern == "ENABLE_CREATOR":
            context.write(context.line)
            context.write("return True\n", indent=2)
            context.write(context.line.replace("isCreator", "chkCreator"))
        elif context.pattern in ("DISABLE_CLIENT_ADS", "DISABLE_ROOM_ADS"):
            context.write(context.line)
            context.write("return False\n", indent=2)
            while context.index + 1 < len(context.source):
                nxt = context.source[context.index + 1]
                if nxt.strip().startswith('def ') or nxt.strip() == '':
                    break
                context.seek(1)
